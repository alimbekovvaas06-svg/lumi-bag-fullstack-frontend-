/* Демонстрационные данные каталога. Для учебного frontend-проекта сервер не нужен. */
const PRODUCTS = [
  { id: 1, name: 'Марта', category: 'Через плечо', description: 'Лаконичная сумка на каждый день', price: 18900, oldPrice: 22900, badge: 'Бестселлер', color: 'Карамельный', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=82' },
  { id: 2, name: 'Софи', category: 'Мини-сумки', description: 'Компактная форма для важных мелочей', price: 14500, oldPrice: null, badge: 'Новинка', color: 'Молочный', image: 'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&w=800&q=82' },
  { id: 3, name: 'Элла', category: 'Шопперы', description: 'Вместительная модель для большого дня', price: 21900, oldPrice: null, badge: '', color: 'Шоколадный', image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=82' },
  { id: 4, name: 'Нора', category: 'Через плечо', description: 'Универсальная модель с мягкими линиями', price: 17500, oldPrice: null, badge: '', color: 'Чёрный', image: 'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=800&q=82' },
  { id: 5, name: 'Лея', category: 'Мини-сумки', description: 'Небольшой акцент для вечернего выхода', price: 12900, oldPrice: 15900, badge: '−19%', color: 'Вишнёвый', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=82' },
  { id: 6, name: 'Айви', category: 'Шопперы', description: 'Всё нужное всегда под рукой', price: 23900, oldPrice: null, badge: 'Вместительная', color: 'Песочный', image: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=82' },
  { id: 7, name: 'Мия', category: 'Через плечо', description: 'Лёгкая сумка для прогулок и встреч', price: 16500, oldPrice: null, badge: '', color: 'Бежевый', image: 'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&w=800&q=82' },
  { id: 8, name: 'Кира', category: 'Шопперы', description: 'Чистый силуэт и много пространства', price: 20500, oldPrice: null, badge: '', color: 'Оливковый', image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=82' }
];

const formatPrice = (value) => new Intl.NumberFormat('ru-KZ', { maximumFractionDigits: 0 }).format(value) + ' ₸';
