(() => {
  'use strict';
  const CART_KEY = 'lumiBagCart';
  const FAVORITES_KEY = 'lumiBagFavorites';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  function readStorage(key, fallback) {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : fallback;
    } catch (error) {
      console.warn(`Не удалось прочитать ${key}:`, error);
      return fallback;
    }
  }
  function writeStorage(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); }
    catch (error) { console.warn(`Не удалось сохранить ${key}:`, error); }
  }
  const getCart = () => readStorage(CART_KEY, []);
  const saveCart = (cart) => { writeStorage(CART_KEY, cart); updateCartCount(); };
  const getFavorites = () => readStorage(FAVORITES_KEY, []);
  const saveFavorites = (favorites) => writeStorage(FAVORITES_KEY, favorites);
  const findProduct = (id) => PRODUCTS.find((product) => product.id === Number(id));

  function updateCartCount() {
    const count = getCart().reduce((sum, item) => sum + item.quantity, 0);
    $$('[data-cart-count]').forEach((element) => { element.textContent = count; element.setAttribute('aria-label', `Товаров в корзине: ${count}`); });
  }

  function productCard(product) {
    const favorites = getFavorites();
    const favorite = favorites.includes(product.id);
    const badge = product.badge ? `<span class="product-badge">${escapeHtml(product.badge)}</span>` : '';
    const oldPrice = product.oldPrice ? `<span class="old-price">${formatPrice(product.oldPrice)}</span>` : '';
    return `<article class="product-card">
      <div class="product-image-wrap">${badge}<img src="${product.image}" alt="Женская сумка ${escapeHtml(product.name)}, цвет ${escapeHtml(product.color)}" loading="lazy"><button class="favorite-button ${favorite ? 'is-favorite' : ''}" type="button" data-favorite="${product.id}" aria-pressed="${favorite}" aria-label="${favorite ? 'Убрать из избранного' : 'Добавить в избранное'}: ${escapeHtml(product.name)}">${favorite ? '♥' : '♡'}</button></div>
      <div class="product-meta"><span>${escapeHtml(product.category)}</span><span>${escapeHtml(product.color)}</span></div>
      <h3>${escapeHtml(product.name)}</h3><p class="product-description">${escapeHtml(product.description)}</p>
      <div class="product-buy"><div class="product-prices"><strong>${formatPrice(product.price)}</strong>${oldPrice}</div><button class="add-button" type="button" data-add-to-cart="${product.id}" aria-label="Добавить в корзину: ${escapeHtml(product.name)}">＋</button></div>
    </article>`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  }

  function renderProducts(container, products) {
    if (!container) return;
    if (!products.length) {
      container.innerHTML = '<div class="empty-results"><span>⌕</span><h3>Ничего не нашлось</h3><p>Попробуй изменить запрос или сбросить фильтры.</p></div>';
      return;
    }
    container.innerHTML = products.map(productCard).join('');
  }

  function addToCart(id) {
    const product = findProduct(id);
    if (!product) return;
    const cart = getCart();
    const existing = cart.find((item) => item.id === product.id);
    if (existing) existing.quantity += 1;
    else cart.push({ id: product.id, quantity: 1 });
    saveCart(cart);
    announce(`${product.name} добавлена в корзину`);
  }

  function toggleFavorite(id, button) {
    const favorites = getFavorites();
    const productId = Number(id);
    const exists = favorites.includes(productId);
    const updated = exists ? favorites.filter((item) => item !== productId) : [...favorites, productId];
    saveFavorites(updated);
    if (button) {
      button.classList.toggle('is-favorite', !exists);
      button.setAttribute('aria-pressed', String(!exists));
      button.setAttribute('aria-label', `${!exists ? 'Убрать из избранного' : 'Добавить в избранное'}: ${findProduct(id)?.name || 'товар'}`);
      button.textContent = !exists ? '♥' : '♡';
    }
    announce(exists ? 'Удалено из избранного' : 'Добавлено в избранное');
  }

  function announce(message) {
    let live = $('[data-live-message]');
    if (!live) {
      live = document.createElement('div');
      live.className = 'live-message';
      live.dataset.liveMessage = '';
      live.setAttribute('role', 'status');
      live.setAttribute('aria-live', 'polite');
      document.body.append(live);
    }
    live.textContent = message;
    live.classList.add('show');
    window.clearTimeout(announce.timeout);
    announce.timeout = window.setTimeout(() => live.classList.remove('show'), 2200);
  }

  function initMenu() {
    const toggle = $('.menu-toggle');
    const nav = $('.site-nav');
    if (!toggle || !nav) return;
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      toggle.setAttribute('aria-label', expanded ? 'Открыть меню' : 'Закрыть меню');
      nav.classList.toggle('is-open', !expanded);
    });
    nav.addEventListener('click', (event) => {
      if (event.target.closest('a')) {
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Открыть меню');
      }
    });
  }

  function initNavigation() {
    const page = document.body.dataset.page;
    const activeLink = $(`[data-nav="${page}"]`);
    if (activeLink) activeLink.setAttribute('aria-current', 'page');
  }

  function initGridEvents() {
    $$('[data-product-grid]').forEach((grid) => grid.addEventListener('click', (event) => {
      const addButton = event.target.closest('[data-add-to-cart]');
      const favoriteButton = event.target.closest('[data-favorite]');
      if (addButton) addToCart(addButton.dataset.addToCart);
      if (favoriteButton) toggleFavorite(favoriteButton.dataset.favorite, favoriteButton);
    }));
  }

  function initCatalog() {
    const grid = $('[data-product-grid="catalog"]');
    if (!grid) return;
    const search = $('[data-search]');
    const category = $('[data-category-filter]');
    const sort = $('[data-sort-filter]');
    const resultsCount = $('[data-results-count]');
    const clear = $('[data-clear-filters]');
    function update() {
      const query = (search?.value || '').trim().toLocaleLowerCase('ru');
      const categoryValue = category?.value || 'all';
      const sortValue = sort?.value || 'featured';
      let visible = PRODUCTS.filter((product) => {
        const matchesQuery = `${product.name} ${product.category} ${product.description} ${product.color}`.toLocaleLowerCase('ru').includes(query);
        const matchesCategory = categoryValue === 'all' || product.category === categoryValue;
        return matchesQuery && matchesCategory;
      });
      if (sortValue === 'price-asc') visible.sort((a, b) => a.price - b.price);
      if (sortValue === 'price-desc') visible.sort((a, b) => b.price - a.price);
      if (sortValue === 'name') visible.sort((a, b) => a.name.localeCompare(b.name, 'ru'));
      renderProducts(grid, visible);
      if (resultsCount) resultsCount.textContent = `Показано ${visible.length} из ${PRODUCTS.length} моделей`;
    }
    [search, category, sort].forEach((element) => element?.addEventListener(element === search ? 'input' : 'change', update));
    clear?.addEventListener('click', () => { search.value = ''; category.value = 'all'; sort.value = 'featured'; update(); });
    update();
  }

  function initFeatured() {
    const grid = $('[data-product-grid="featured"]');
    if (grid) renderProducts(grid, PRODUCTS.filter((product) => [1, 2, 3, 4].includes(product.id)));
  }

  function initNewsletter() {
    const form = $('[data-newsletter-form]');
    if (!form) return;
    const message = $('[data-newsletter-message]');
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const input = $('input[type="email"]', form);
      if (!input.checkValidity()) {
        input.reportValidity();
        if (message) message.textContent = 'Введи корректный адрес электронной почты.';
        return;
      }
      if (message) message.textContent = 'Спасибо! В учебной версии подписка только демонстрируется.';
      form.reset();
    });
  }

  function renderCart() {
    const container = $('[data-cart-items]');
    if (!container) return;
    const cart = getCart().filter((item) => findProduct(item.id) && item.quantity > 0);
    saveCart(cart);
    const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const label = $('[data-cart-item-label]');
    if (label) label.textContent = `${itemCount} ${itemCount === 1 ? 'товар' : itemCount >= 2 && itemCount <= 4 ? 'товара' : 'товаров'}`;
    if (!cart.length) {
      container.innerHTML = '<div class="cart-empty"><span class="empty-bag">♡</span><h3>Пока здесь пусто</h3><p>В каталоге много красивых вариантов — самое время найти любимую сумку.</p><a class="button button-dark" href="catalog.html">Перейти в каталог <span aria-hidden="true">↗</span></a></div>';
    } else {
      container.innerHTML = cart.map((item) => {
        const product = findProduct(item.id);
        return `<article class="cart-item" data-cart-item="${product.id}"><img src="${product.image}" alt="Сумка ${escapeHtml(product.name)}" loading="lazy"><div class="cart-item-details"><span class="cart-item-category">${escapeHtml(product.category)}</span><h3>${escapeHtml(product.name)}</h3><p>${escapeHtml(product.color)}</p><strong>${formatPrice(product.price)}</strong><div class="quantity-control" aria-label="Количество ${escapeHtml(product.name)}"><button type="button" data-quantity-change="-1" data-id="${product.id}" aria-label="Уменьшить количество">−</button><span>${item.quantity}</span><button type="button" data-quantity-change="1" data-id="${product.id}" aria-label="Увеличить количество">＋</button></div></div><button class="remove-item" type="button" data-remove-item="${product.id}" aria-label="Удалить ${escapeHtml(product.name)}">×</button></article>`;
      }).join('');
    }
    const subtotal = cart.reduce((sum, item) => sum + findProduct(item.id).price * item.quantity, 0);
    const priceTargets = { subtotal: $('[data-subtotal]'), total: $('[data-total]') };
    if (priceTargets.subtotal) priceTargets.subtotal.textContent = formatPrice(subtotal);
    if (priceTargets.total) priceTargets.total.textContent = formatPrice(subtotal);
    const submitButton = $('[data-checkout-form] button[type="submit"]');
    if (submitButton) submitButton.disabled = !cart.length;
  }

  function initCart() {
    const container = $('[data-cart-items]');
    if (!container) return;
    renderCart();
    container.addEventListener('click', (event) => {
      const quantityButton = event.target.closest('[data-quantity-change]');
      const removeButton = event.target.closest('[data-remove-item]');
      if (quantityButton) {
        const id = Number(quantityButton.dataset.id);
        const change = Number(quantityButton.dataset.quantityChange);
        const cart = getCart();
        const item = cart.find((entry) => entry.id === id);
        if (item) item.quantity += change;
        saveCart(cart.filter((entry) => entry.quantity > 0));
        renderCart();
      }
      if (removeButton) {
        saveCart(getCart().filter((entry) => entry.id !== Number(removeButton.dataset.removeItem)));
        renderCart();
        announce('Товар удалён из корзины');
      }
    });

    const form = $('[data-checkout-form]');
    const message = $('[data-checkout-message]');
    const dialog = $('[data-success-dialog]');
    form?.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!getCart().length) {
        if (message) message.textContent = 'Добавь товар в корзину перед оформлением заказа.';
        return;
      }
      if (!form.checkValidity()) {
        form.reportValidity();
        if (message) message.textContent = 'Проверь, пожалуйста, все поля формы.';
        return;
      }
      if (dialog && typeof dialog.showModal === 'function') dialog.showModal();
      else alert('Заказ оформлен в демонстрационном режиме. Платёж не выполнялся.');
      saveCart([]);
      form.reset();
      renderCart();
      if (message) message.textContent = '';
    });
    $('[data-close-dialog]')?.addEventListener('click', () => {
      dialog?.close();
      window.location.href = 'catalog.html';
    });
    dialog?.addEventListener('click', (event) => {
      if (event.target === dialog) dialog.close();
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    initMenu();
    initNavigation();
    updateCartCount();
    initFeatured();
    initCatalog();
    initGridEvents();
    initNewsletter();
    initCart();
  });
})();
